data:extend({
  {
    type = "item-subgroup",
    name = "angels-alloys-casting",
    group = "angels-casting",
    order = "y",
  },
  {
    type = "item-subgroup",
    name = "angels-brass-casting",
    group = "angels-casting",
    order = "x",
  },
  {
    type = "item-subgroup",
    name = "angels-cobalt-steel-casting",
    group = "angels-casting",
    order = "w",
  },
  {
    type = "item-subgroup",
    name = "angels-nitinol-casting",
    group = "angels-casting",
    order = "v",
  },
  {
    type = "item-subgroup",
    name = "angels-invar-casting",
    group = "angels-casting",
    order = "u",
  },
  {
    type = "item-subgroup",
    name = "angels-bronze-casting",
    group = "angels-casting",
    order = "t",
  },

})
